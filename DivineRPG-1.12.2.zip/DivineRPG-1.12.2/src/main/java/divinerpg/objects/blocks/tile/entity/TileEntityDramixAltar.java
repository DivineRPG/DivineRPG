package divinerpg.objects.blocks.tile.entity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityDramixAltar extends TileEntity {
    public TileEntityDramixAltar() {
    }
}
