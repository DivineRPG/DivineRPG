package divinerpg.objects.blocks.tile.entity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityParasectaAltar extends TileEntity {
    public TileEntityParasectaAltar() {
    }
}
