package divinerpg.objects.blocks.tile.entity;

public class TileEntityFrostedChest extends TileEntityModChest {

    public String getChestName() {
        return "tile.frosted_chest.name";
    }
}