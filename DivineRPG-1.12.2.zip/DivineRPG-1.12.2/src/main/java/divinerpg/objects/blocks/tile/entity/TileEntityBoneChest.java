package divinerpg.objects.blocks.tile.entity;

public class TileEntityBoneChest extends TileEntityModChest {

    public String getChestName() {
        return "tile.bone_chest.name";
    }
}