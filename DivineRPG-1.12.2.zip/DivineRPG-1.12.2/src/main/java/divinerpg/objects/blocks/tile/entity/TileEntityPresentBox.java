package divinerpg.objects.blocks.tile.entity;

public class TileEntityPresentBox extends TileEntityModChest {

    public String getChestName() {
        return "tile.present_box.name";
    }
}