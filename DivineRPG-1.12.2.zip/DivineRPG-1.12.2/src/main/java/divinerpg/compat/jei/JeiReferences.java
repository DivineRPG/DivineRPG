package divinerpg.compat.jei;

import divinerpg.DivineRPG;

public class JeiReferences {
    public static final String JACK_O_MAN_CATEGORY = DivineRPG.MODID + ":jack_o_man";
    public static final String WORKSHOP_MERCHANT_CATEGORY = DivineRPG.MODID + ":workshop_merchant";
    public static final String WORKSHOP_TINKERER_CATEGORY = DivineRPG.MODID + ":workshop_tinkerer";
    public static final String CAPITAIN_MERIC_CATEGORY = DivineRPG.MODID + ":capitain_meric";
    public static final String LIVESTOCK_MERCHANT_CATEGORY = DivineRPG.MODID + ":livestock_merchant";
    public static final String WAR_GENERAL_CATEGORY = DivineRPG.MODID + ":war_general";
    public static final String LEORNA_CATEGORY = DivineRPG.MODID + ":leorna";
    public static final String DATTICON_CATEGORY = DivineRPG.MODID + ":datticon";
    public static final String LORD_VATTICUS_CATEGORY = DivineRPG.MODID + ":lord_vatticus";
    public static final String ZELUS_CATEGORY = DivineRPG.MODID + ":zelus";
    public static final String ARCANA_EXTRACTOR_CATEGORY = DivineRPG.MODID + ":arcana_extractor";
}
