@API(apiVersion = APIReference.API_VERSION, owner = DivineRPG.MODID, provides = "DivineAPI")
package divinerpg.api;

import divinerpg.DivineRPG;
import net.minecraftforge.fml.common.API;