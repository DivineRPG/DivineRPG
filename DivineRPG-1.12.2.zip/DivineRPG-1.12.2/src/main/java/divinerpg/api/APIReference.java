package divinerpg.api;

public class APIReference {
    public static final String API_VERSION = "1.0";

}
