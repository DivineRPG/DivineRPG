package divinerpg.enums;

/**
 * Created by LiteWolf101 on Feb /07/2019
 */
public enum ParticleType {
    NONE,
    APALACHIA_PORTAL,
    EDEN_PORTAL,
    MORTUM_PORTAL,
    SKYTHERN_PORTAL,
    WILDWOOD_PORTAL,
    GREEN_PORTAL,
    BLACK_FLAME,
    BLUE_FLAME,
    GREEN_FLAME,
    PURPLE_FLAME,
    FROST,
    SPARKLER,
    ENDER_TRIPLET
}
