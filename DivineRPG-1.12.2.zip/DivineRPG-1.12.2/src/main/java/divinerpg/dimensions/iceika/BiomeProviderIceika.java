package divinerpg.dimensions.iceika;

import divinerpg.registry.BiomeRegistry;
import net.minecraft.world.biome.BiomeProviderSingle;

public class BiomeProviderIceika extends BiomeProviderSingle {
	public BiomeProviderIceika() {
		super(BiomeRegistry.biomeIceika);
	}
}