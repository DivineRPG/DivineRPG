package divinerpg.dimensions.vethea;

import divinerpg.registry.BiomeRegistry;
import net.minecraft.world.biome.BiomeProviderSingle;

public class BiomeProviderVethea extends BiomeProviderSingle {

    public BiomeProviderVethea() {
        super(BiomeRegistry.biomeVethea);
    }
}
