## Credits
* XolovA - original creator
* Tslat (Scimiguy) - current owner and coding assistant

### Main Team
* NicosaurusRex99 - Developer
* Dash - Developer
* Zachtoplasm - Texture artist

### Ex-Developers
* AstralScourge
* krwminer
* Wufflez (LiteWolf101)
* RadioactiveStud
* Eternaldoom
* The_SlayerMC
* Sheenrox82
* Mazetar
* TLHPoE
* Aginsun
* Hologuardian
* Vazkii
* Blued00r

### Translations
* Imbarainbow - Simplified Chinese translations
* MCUmbrella - Simplified Chinese translations
* Locomen - Russian translations
* Dash - Russian translations
* FrozenYT - Russian translations
* Kellixon - Russian translations
* Davoleo - Italian translations


### Older Version Translations
* TikenTVC - Portuguese translations
* THEVOLCO - German translations
* ShadowOfStrelok - Russian translations
* fewizz - Russian translations
* Adaptivity - Russian translations

### Special Thanks to
* Dizzlepop12 - A few models/textures
* Declan (UKDeccy) - A few models/textures
* BlueEyes9 - A few models/textures
* Insanity414all - Former wiki admin
* Laorwick - Some recipes
* BossLetsPlays - Sound artist, maintenance developer, and former server owner
* Sactage - Former server owner and maintainer

### Other Credits
* Majorsir - for the name of the mod.
* Terraria - for some resources. (removed in 1.12.2)
* Vattic - for some block textures, featured in a version of the faithful32 pack (removed in 1.12.2)
* Reika - for ore textures.
* XL biomes - for tree style. (removed in 1.12.2)
